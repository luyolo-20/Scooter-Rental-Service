package com.scooter.enums;

public enum ScooterStatus {
    AVAILABLE, NOT_AVAILABLE;
}
