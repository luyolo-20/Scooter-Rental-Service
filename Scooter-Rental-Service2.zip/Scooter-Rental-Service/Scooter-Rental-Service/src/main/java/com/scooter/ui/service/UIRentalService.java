package com.scooter.ui.service;

public class UIRentalService {
}
