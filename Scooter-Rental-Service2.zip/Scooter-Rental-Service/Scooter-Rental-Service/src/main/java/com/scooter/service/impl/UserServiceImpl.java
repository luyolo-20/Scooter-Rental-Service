package com.scooter.service.impl;

import com.scooter.domain.User;
import com.scooter.enums.UserRole;
import com.scooter.factory.UserRQ;
import com.scooter.repository.BaseCrudRepository;
import com.scooter.repository.UserRepository;
import com.scooter.service.UserService;
import jakarta.annotation.PostConstruct;
import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Service;

@Service
public class UserServiceImpl extends BaseCrudServiceImpl<User, Long> implements UserService {
    private final UserRepository userRepository;
    public UserServiceImpl(BaseCrudRepository<User, Long> repository, UserRepository userRepository) {
        super(repository);
        this.userRepository = userRepository;
    }

    @Override
    public User create(UserRQ form) {
        User user = new User();
        BeanUtils.copyProperties(form, user);
        user.setUserRole(UserRole.EMPLOYEE);
        return userRepository.save(user);
    }

    @Override
    public User update(Long id, UserRQ form) {
        User user = getById(id);
        BeanUtils.copyProperties(form, user);
        return userRepository.save(user);
    }

    @Override
    public User findByEmail(String email) {
        return userRepository.findByEmail(email)
                .orElse(null);
    }

    @PostConstruct
    public void initializeAdminAndEmployee() {
        if (userRepository.countByUserRole(UserRole.ADMIN) == 0) {
            User user = new User();
            user.setName("Admin");
            user.setEmail("admin@gmail.com");
            user.setPassword("1111");
            user.setUserRole(UserRole.ADMIN);
            user.setPhone("0786598745");
            user.setNic("ADMIN123");

            userRepository.save(user);
            System.out.println("Admin has been initialized.");
        }

        if (userRepository.countByUserRole(UserRole.EMPLOYEE) == 0) {
            User employee = new User();
            employee.setName("Employee");
            employee.setEmail("employee@gmail.com");
            employee.setPassword("1111");
            employee.setUserRole(UserRole.EMPLOYEE);
            employee.setPhone("0896532568");
            employee.setNic("EMPLOYEE123");

            userRepository.save(employee);
            System.out.println("Employee has been initialized.");
        }
    }
}
