package com.scooter.enums;

public enum RentalStatus {
    PENDING, ACCEPTED, REJECTED, COMPLETED;
}
