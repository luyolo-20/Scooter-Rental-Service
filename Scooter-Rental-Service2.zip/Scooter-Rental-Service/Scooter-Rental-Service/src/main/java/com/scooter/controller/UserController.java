package com.scooter.controller;

import com.scooter.domain.User;
import com.scooter.factory.UserRQ;
import com.scooter.service.UserService;
import lombok.AllArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/users")
@AllArgsConstructor
public class UserController {
    private final UserService userService;

    @GetMapping("")
    public List<User> list() {
        return userService.getAll();
    }

    @GetMapping("/{id}")
    public User getById(@PathVariable Long id) {
        return userService.getById(id);
    }

    @PostMapping("")
    public User create(@RequestBody UserRQ form) {
        return userService.create(form);
    }

    @PutMapping("/{id}")
    public User update(@PathVariable Long id, @RequestBody UserRQ form) {
        return userService.update(id, form);
    }

    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void deleteById(@PathVariable Long id) {
        userService.delete(id);
    }
}
