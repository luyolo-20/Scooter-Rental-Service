package com.scooter.ui;

import com.scooter.domain.Customer;
import com.scooter.domain.User;
import com.scooter.service.*;
import com.scooter.service.CustomerService;
import com.scooter.ui.panel.LoginPanel;
import com.scooter.ui.panel.CustomerDashboard;
import com.scooter.ui.panel.EmployeeDashboard;
import com.scooter.ui.panel.AdminDashboard;
import com.scooter.ui.service.UIAuthenticationService;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

import javax.swing.*;
import java.awt.*;

@SpringBootApplication
@ComponentScan(basePackages = {"com.scooter"})
@EntityScan("com.scooter.domain")
@EnableJpaRepositories("com.scooter.repository")
public class ScooterRentalApp extends JFrame {
    private CardLayout cardLayout;
    private JPanel mainPanel;
    private LoginPanel loginPanel;
    private CustomerDashboard customerDashboard;
    private EmployeeDashboard employeeDashboard;
    private AdminDashboard adminDashboard;

    public ScooterRentalApp(ConfigurableApplicationContext context) {
        setTitle("Scooter Rental System");
        setExtendedState(JFrame.MAXIMIZED_BOTH);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        // Center the window on the screen
        setLocationRelativeTo(null);

        cardLayout = new CardLayout();
        mainPanel = new JPanel(cardLayout);

        UIAuthenticationService authService = new UIAuthenticationService();
        UserService userService = context.getBean(UserService.class);
        com.scooter.service.CustomerService customerService = context.getBean(CustomerService.class);
        ScooterService scooterService = context.getBean(ScooterService.class);
        FileStoreService fileStoreService = context.getBean(FileStoreService.class);
        RentalService rentalService = context.getBean(RentalService.class);

        loginPanel = new LoginPanel(authService, this::onLoginSuccess);
        customerDashboard = new CustomerDashboard(customerService, scooterService,rentalService);
        customerDashboard.setLogoutListener(this::handleLogout);
        employeeDashboard = new EmployeeDashboard(userService, customerService, scooterService, fileStoreService, rentalService);
        employeeDashboard.setLogoutListener(this::handleLogout);
        adminDashboard = new AdminDashboard(userService, customerService, scooterService, fileStoreService, rentalService);
        adminDashboard.setLogoutListener(this::handleLogout);

        mainPanel.add(loginPanel, "LOGIN");
        mainPanel.add(customerDashboard, "CUSTOMER");
        mainPanel.add(employeeDashboard, "EMPLOYEE");
        mainPanel.add(adminDashboard, "ADMIN");

        add(mainPanel);
        cardLayout.show(mainPanel, "LOGIN");
    }

    private void onLoginSuccess(String role, Object loggedInUser) {
        if ("ADMIN".equalsIgnoreCase(role)) {
            adminDashboard.setLoggedInAdmin((User) loggedInUser);
        } else if ("EMPLOYEE".equalsIgnoreCase(role)) {
            employeeDashboard.setLoggedInEmployee((User) loggedInUser);
        } else if ("CUSTOMER".equalsIgnoreCase(role)) {
            customerDashboard.setLoggedInCustomer((Customer) loggedInUser);
        }
        cardLayout.show(mainPanel, role.toUpperCase());
    }

    private void handleLogout() {
        // Reset any necessary application state
        cardLayout.show(mainPanel, "LOGIN");
        // Optionally, reset the login panel
        loginPanel.reset(); // You'll need to implement this method in LoginPanel
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            ConfigurableApplicationContext context = new SpringApplicationBuilder(ScooterRentalApp.class)
                    .headless(false)
                    .run(args);

            ScooterRentalApp app = new ScooterRentalApp(context);
            app.setVisible(true);
        });
    }
}