package com.scooter.service.impl;

import com.scooter.domain.Customer;
import com.scooter.factory.CustomerRQ;
import com.scooter.repository.BaseCrudRepository;
import com.scooter.repository.CustomerRepository;
import com.scooter.service.CustomerService;
import jakarta.annotation.PostConstruct;
import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Service;

@Service
public class CustomerServiceImpl extends BaseCrudServiceImpl<Customer, Long> implements CustomerService {
    private final CustomerRepository customerRepository;
    public CustomerServiceImpl(BaseCrudRepository<Customer, Long> repository, CustomerRepository customerRepository) {
        super(repository);
        this.customerRepository = customerRepository;
    }


    @Override
    public Customer create(CustomerRQ form) {
        Customer customer = new Customer();
        BeanUtils.copyProperties(form, customer);
        return customerRepository.save(customer);
    }

    @Override
    public Customer update(Long id, CustomerRQ form) {
        Customer customer = getById(id);
        BeanUtils.copyProperties(form, customer);
        return customerRepository.save(customer);
    }

    public Customer findByEmail(String email) {
        return customerRepository.findByEmail(email)
                .orElse(null);
    }

    @PostConstruct
    private void initializeCustomer() {
        if (customerRepository.count() == 0) {
            Customer customer = new Customer();
            customer.setName("Siya Tshitshi");
            customer.setEmail("tshitshi@gmail.com");
            customer.setPassword("1111");
            customer.setPhone("0765984321");
            customer.setNic("CUST123");

            customerRepository.save(customer);
            System.out.println("Initial customer has been created.");
        }
    }
}
