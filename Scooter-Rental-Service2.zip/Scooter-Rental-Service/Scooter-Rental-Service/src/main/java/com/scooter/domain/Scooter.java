package com.scooter.domain;

import com.scooter.enums.Model;
import com.scooter.enums.ScooterStatus;
import io.hypersistence.utils.hibernate.type.json.JsonType;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.Type;

@Entity
@AllArgsConstructor
@NoArgsConstructor
@Data
@Table(name = "scooters")
public class Scooter {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private Model model;

    private int year;

    private int rentalPerDay;

    private ScooterStatus status;

    @Type(JsonType.class)
    @Column(columnDefinition = "json")
    private Attachment image;

}
