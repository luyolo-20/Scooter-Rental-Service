package com.scooter.repository;

import com.scooter.domain.User;
import com.scooter.enums.UserRole;

import java.util.Optional;

public interface UserRepository extends BaseCrudRepository<User, Long>{
    int countByUserRole(UserRole userRole);

    Optional<User> findByEmail(String email);
}
