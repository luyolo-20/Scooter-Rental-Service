package com.scooter.repository;

import com.querydsl.core.BooleanBuilder;
import com.scooter.domain.Scooter;

import java.util.List;

public interface ScooterRepository extends BaseCrudRepository<Scooter, Long>{
}
