package com.scooter.service;

import com.scooter.domain.Scooter;
import com.scooter.factory.ScooterRQ;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;

public interface ScooterService extends BaseCrudService<Scooter, Long>{
    Scooter create(ScooterRQ form, MultipartFile file);

    Scooter update(Long id, ScooterRQ form, MultipartFile file);

    Scooter update(Long id, ScooterRQ form);

    List<Scooter> search(String q);
}
