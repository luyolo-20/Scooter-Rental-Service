package com.scooter.enums;

public enum UserRole {
    ADMIN, EMPLOYEE
}
