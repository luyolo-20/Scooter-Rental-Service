package com.scooter.ui.panel;

public class ScooterManagementPanel {
}
