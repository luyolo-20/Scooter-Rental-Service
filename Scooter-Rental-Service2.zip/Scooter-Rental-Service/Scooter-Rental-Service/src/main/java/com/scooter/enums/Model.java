package com.scooter.enums;

public enum Model {
    HONDA, TVS, SUZUKI, BAJAJ, YAMAHA
}
