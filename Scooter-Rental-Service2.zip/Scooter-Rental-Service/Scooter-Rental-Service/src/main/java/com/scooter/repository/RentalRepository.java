package com.scooter.repository;

import com.scooter.domain.RentalDetail;

import java.util.List;

public interface RentalRepository extends BaseCrudRepository<RentalDetail, Long>{
    List<RentalDetail> findByCustomerId(Long customerId);
}
