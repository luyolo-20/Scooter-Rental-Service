package com.scooter.ui.dialog;

public class LoginDialog {
}
