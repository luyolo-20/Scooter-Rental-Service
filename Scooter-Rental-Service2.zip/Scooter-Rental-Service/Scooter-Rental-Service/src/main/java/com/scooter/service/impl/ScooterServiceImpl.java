package com.scooter.service.impl;

import com.querydsl.core.BooleanBuilder;
import com.scooter.domain.Attachment;
import com.scooter.domain.QScooter;
import com.scooter.domain.Scooter;
import com.scooter.enums.Model;
import com.scooter.enums.ScooterStatus;
import com.scooter.factory.ScooterRQ;
import com.scooter.repository.BaseCrudRepository;
import com.scooter.repository.ScooterRepository;
import com.scooter.service.FileStoreService;
import com.scooter.service.ScooterService;
import jakarta.annotation.PostConstruct;
import org.apache.commons.io.FilenameUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;
import java.util.UUID;

@Service
public class ScooterServiceImpl extends BaseCrudServiceImpl<Scooter, Long> implements ScooterService {
    private final ScooterRepository scooterRepository;
    private final FileStoreService fileStoreService;

    public ScooterServiceImpl(BaseCrudRepository<Scooter, Long> repository, ScooterRepository scooterRepository, FileStoreService fileStoreService) {
        super(repository);
        this.scooterRepository = scooterRepository;
        this.fileStoreService = fileStoreService;
    }

    @Override
    public Scooter create(ScooterRQ form, MultipartFile file) {
        Scooter scooter = new Scooter();
        BeanUtils.copyProperties(form, scooter);
        scooter.setStatus(ScooterStatus.AVAILABLE);

        var ext = FilenameUtils.getExtension(file.getOriginalFilename());
        var relativePath = "scooter-%s.%s".formatted(UUID.randomUUID().toString(), ext);
        Attachment attachment = fileStoreService.storeFile(relativePath, file);
        scooter.setImage(attachment);
        return scooterRepository.save(scooter);
    }

    @Override
    public Scooter update(Long id, ScooterRQ form, MultipartFile file) {
        Scooter scooter = getById(id);
        BeanUtils.copyProperties(form, scooter);

        String oldPath = (scooter.getImage() != null) ? scooter.getImage().getPath() : null;
        var ext = FilenameUtils.getExtension(file.getOriginalFilename());
        var relativePath = "scooter-%s.%s".formatted(UUID.randomUUID().toString(), ext);
        Attachment attachment = fileStoreService.storeFile(relativePath, file);
        scooter.setImage(attachment);
        if (oldPath != null) {
            fileStoreService.deleteFile(oldPath);
        }

        return scooterRepository.save(scooter);
    }

    @Override
    public Scooter update(Long id, ScooterRQ form) {
        Scooter scooter = getById(id);
        BeanUtils.copyProperties(form, scooter);

        return scooterRepository.save(scooter);
    }

    @Override
    public List<Scooter> search(String q) {
        if (q != null && !q.isBlank()) {
            BooleanBuilder predicate = new BooleanBuilder();

            for (ScooterStatus status : ScooterStatus.values()) {
                if (status.name().toLowerCase().contains(q.toLowerCase())) {
                    predicate.or(QScooter.scooter.status.eq(status));
                }
            }

            for (Model model : Model.values()) {
                if (model.name().toLowerCase().contains(q.toLowerCase())) {
                    predicate.or(QScooter.scooter.model.eq(model));
                }
            }
            predicate.or(QScooter.scooter.model.stringValue().toLowerCase().containsIgnoreCase(q.toLowerCase()));

            if (q.matches("\\d+")) {
                predicate.or(QScooter.scooter.id.eq(Long.valueOf(q))
                        .or(QScooter.scooter.rentalPerDay.eq(Integer.valueOf(q))));
            }

            return (List<Scooter>) scooterRepository.findAll(predicate);
        }

        return scooterRepository.findAll();
    }

    @PostConstruct
    private void initializeScooter() {
        if (scooterRepository.count() == 0) {
            Scooter scooter = new Scooter();
            scooter.setModel(Model.HONDA);
            scooter.setYear(2020);
            scooter.setRentalPerDay(50);
            scooter.setStatus(ScooterStatus.AVAILABLE);

            Attachment attachment = new Attachment();
            attachment.setPath("/src/main/resources/static");
            attachment.setUrl("/scooter-9ac23255-1d77-4c4d-a9e9-e7de66a946b1.jpg");
            attachment.setBytes(1024L);
            attachment.setContentType("image/jpeg");

            scooter.setImage(attachment);

            scooterRepository.save(scooter);
            System.out.println("Initial scooter has been created.");
        }
        if (scooterRepository.count() < 2) {
            Scooter scooter = new Scooter();
            scooter.setModel(Model.HONDA);
            scooter.setYear(2022);
            scooter.setRentalPerDay(40);
            scooter.setStatus(ScooterStatus.AVAILABLE);

            Attachment attachment = new Attachment();
            attachment.setPath("/src/main/resources/static");
            attachment.setUrl("/scooter-9ac23255-1d77-4c4d-a9e9-e7de66a946b1.jpg");
            attachment.setBytes(1024L);
            attachment.setContentType("image/jpeg");

            scooter.setImage(attachment);

            scooterRepository.save(scooter);
            System.out.println("Initial scooter 2 has been created.");
        }
        if (scooterRepository.count() < 3) {
            Scooter scooter = new Scooter();
            scooter.setModel(Model.YAMAHA);
            scooter.setYear(2019);
            scooter.setRentalPerDay(30);
            scooter.setStatus(ScooterStatus.AVAILABLE);

            Attachment attachment = new Attachment();
            attachment.setPath("/src/main/resources/static");
            attachment.setUrl("/scooter-9ac23255-1d77-4c4d-a9e9-e7de66a946b1.jpg");
            attachment.setBytes(1024L);
            attachment.setContentType("image/jpeg");

            scooter.setImage(attachment);

            scooterRepository.save(scooter);
            System.out.println("Initial scooter 2 has been created.");
        }
    }
}



