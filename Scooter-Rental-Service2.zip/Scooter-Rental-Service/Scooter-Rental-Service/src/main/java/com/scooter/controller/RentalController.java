package com.scooter.controller;

import com.scooter.domain.RentalDetail;
import com.scooter.factory.RentalRQ;
import com.scooter.service.RentalService;
import lombok.AllArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/rentals")
@AllArgsConstructor
public class RentalController {
    private RentalService rentalService;

    @GetMapping("")
    public List<RentalDetail> list() {
        return rentalService.getAll();
    }

    @GetMapping("/{id}")
    public RentalDetail getById(@PathVariable Long id) {
        return rentalService.getById(id);
    }

    @PostMapping("")
    public RentalDetail create(@RequestBody RentalRQ form) {
        return rentalService.create(form);
    }

    @PutMapping("/{id}")
    public RentalDetail update(@PathVariable Long id, @RequestBody RentalRQ form) {
        return rentalService.update(id, form);
    }

    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void deleteById(@PathVariable Long id) {
        rentalService.delete(id);
    }

    @PutMapping("/{id}/accept")
    public RentalDetail acceptRental(@PathVariable Long id) {
        return rentalService.acceptRental(id);
    }

    @PutMapping("/{id}/reject")
    public RentalDetail rejectRental(@PathVariable Long id) {
        return rentalService.rejectRental(id);
    }

    @PutMapping("/{id}/complete")
    public RentalDetail completeRental(@PathVariable Long id) {
        return rentalService.completeRental(id);
    }
}
