package com.scooter.ui.panel;

import com.scooter.domain.Customer;
import com.scooter.domain.RentalDetail;
import com.scooter.domain.Scooter;
import com.scooter.enums.ScooterStatus;
import com.scooter.factory.RentalRQ;
import com.scooter.service.*;
import lombok.Setter;

import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.net.URL;
import java.time.LocalDate;
import java.util.List;

public class CustomerDashboard extends JPanel {
    private CardLayout cardLayout;
    private JPanel contentPanel;
    private String[] tabs = {"Dashboard", "Profile", "My Rentals", "Search", "Logout"};
    private CustomerService customerService;
    private ScooterService scooterService;
    private RentalService rentalService;
    private Customer loggedInCustomer;
    @Setter
    private LogoutListener logoutListener;

    // Define colors
    private static final Color BACKGROUND_COLOR = new Color(240, 240, 245);
    private static final Color HEADER_COLOR = new Color(60, 60, 60);
    private static final Color BOOK_BUTTON_COLOR = new Color(40, 167, 69);
    private static final Color TEXT_COLOR = new Color(33, 37, 41);
    private static final Color ACCENT_COLOR = new Color(0, 123, 255);

    public CustomerDashboard(CustomerService customerService, ScooterService scooterService, RentalService rentalService) {
        this.customerService = customerService;
        this.scooterService = scooterService;
        this.rentalService = rentalService;
        setLayout(new BorderLayout());
        setBackground(BACKGROUND_COLOR);

        JPanel headerPanel = createHeaderPanel();
        add(headerPanel, BorderLayout.NORTH);

        contentPanel = new JPanel();
        cardLayout = new CardLayout();
        contentPanel.setLayout(cardLayout);
        add(contentPanel, BorderLayout.CENTER);

        showDashboard();
    }

    private JPanel createHeaderPanel() {
        JPanel headerPanel = new JPanel(new BorderLayout());
        headerPanel.setBackground(HEADER_COLOR);
        headerPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        JLabel systemLabel = new JLabel("Scooter Rental System");
        systemLabel.setFont(new Font("Arial", Font.BOLD, 24));
        systemLabel.setForeground(Color.WHITE);
        headerPanel.add(systemLabel, BorderLayout.WEST);

        JLabel dashboardLabel = new JLabel("Customer Dashboard");
        dashboardLabel.setFont(new Font("Arial", Font.PLAIN, 18));
        dashboardLabel.setForeground(Color.WHITE);
        headerPanel.add(dashboardLabel, BorderLayout.EAST);

        JPanel navPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 5));
        navPanel.setBackground(HEADER_COLOR);
        for (String tabName : tabs) {
            JButton tabButton = createStyledButton(tabName);
            navPanel.add(tabButton);
        }

        headerPanel.add(navPanel, BorderLayout.SOUTH);

        return headerPanel;
    }

    private JButton createStyledButton(String text) {
        JButton button = new JButton(text);
        button.setFont(new Font("Arial", Font.BOLD, 14));
        button.setForeground(Color.WHITE);
        button.setBackground(HEADER_COLOR);
        button.setBorderPainted(false);
        button.setFocusPainted(false);
        button.setCursor(new Cursor(Cursor.HAND_CURSOR));
        button.addActionListener(e -> updateContent(text));
        button.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                button.setBackground(HEADER_COLOR.brighter());
            }
            @Override
            public void mouseExited(MouseEvent e) {
                button.setBackground(HEADER_COLOR);
            }
        });
        return button;
    }

    public void setLoggedInCustomer(Customer customer) {
        this.loggedInCustomer = customer;
        SwingUtilities.invokeLater(this::updateDashboardContent);
    }

    private void updateDashboardContent() {
        if (loggedInCustomer != null) {
            JPanel dashboardPanel = createDashboardPanel();
            contentPanel.removeAll();
            contentPanel.add(dashboardPanel, "Dashboard");
            cardLayout.show(contentPanel, "Dashboard");
            contentPanel.revalidate();
            contentPanel.repaint();
        }
    }

    private void updateContent(String selectedTab) {
        contentPanel.removeAll();
        JPanel newPanel;

        switch (selectedTab) {
            case "Profile":
                newPanel = new CustomerProfilePanel(loggedInCustomer, customerService);
                break;
            case "My Rentals":
                newPanel = new CustomerRentalsPanel(loggedInCustomer, rentalService);
                break;
            case "Dashboard":
                newPanel = createDashboardPanel();
                break;
            case "Search":
                newPanel = createSearchPanel();
                break;
            case "Logout":
                handleLogout();
                return;
            default:
                newPanel = new JPanel();
                newPanel.add(new JLabel(selectedTab + " Content"));
        }

        contentPanel.add(newPanel, selectedTab);
        cardLayout.show(contentPanel, selectedTab);
        contentPanel.revalidate();
        contentPanel.repaint();
    }

    private JPanel createDashboardPanel() {
        JPanel dashboardPanel = new JPanel(new BorderLayout(20, 20));
        dashboardPanel.setBackground(BACKGROUND_COLOR);
        dashboardPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        JLabel welcomeLabel = new JLabel("Welcome to Customer Dashboard");
        welcomeLabel.setFont(new Font("Arial", Font.BOLD, 24));
        welcomeLabel.setForeground(TEXT_COLOR);
        dashboardPanel.add(welcomeLabel, BorderLayout.NORTH);

        JPanel scooterCardsPanel = new JPanel(new GridLayout(0, 3, 20, 20));
        scooterCardsPanel.setBackground(BACKGROUND_COLOR);
        List<Scooter> scooters = scooterService.getAll();
        for (Scooter scooter : scooters) {
            ScooterCard card = new ScooterCard(scooter);
            scooterCardsPanel.add(card);
        }

        JScrollPane scrollPane = new JScrollPane(scooterCardsPanel);
        scrollPane.setBackground(BACKGROUND_COLOR);
        scrollPane.setBorder(BorderFactory.createEmptyBorder());
        dashboardPanel.add(scrollPane, BorderLayout.CENTER);

        return dashboardPanel;
    }

    private void showDashboard() {
        updateContent("Dashboard");
    }

    private void handleLogout() {
        int confirm = JOptionPane.showConfirmDialog(this,
                "Are you sure you want to logout?", "Confirm Logout",
                JOptionPane.YES_NO_OPTION);
        if (confirm == JOptionPane.YES_OPTION) {
            if (logoutListener != null) {
                logoutListener.onLogout();
            }
        }
    }

    public interface LogoutListener {
        void onLogout();
    }

    private void bookScooter(Scooter scooter) {
        JTextField daysField = new JTextField(5);
        JPanel panel = new JPanel();
        panel.add(new JLabel("Number of days to rent:"));
        panel.add(daysField);

        int result = JOptionPane.showConfirmDialog(null, panel,
                "Book Scooter", JOptionPane.OK_CANCEL_OPTION);
        if (result == JOptionPane.OK_OPTION) {
            try {
                int days = Integer.parseInt(daysField.getText());
                RentalRQ rentalRQ = new RentalRQ();
                rentalRQ.setCustomerId(loggedInCustomer.getId());
                rentalRQ.setScooterId(scooter.getId());
                rentalRQ.setStartDate(LocalDate.now());
                rentalRQ.setNoOfDates(days);

                RentalDetail rental = rentalService.create(rentalRQ);
                JOptionPane.showMessageDialog(this, "Scooter booked successfully!");
                refreshDashboard();
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(this, "Please enter a valid number of days.", "Error", JOptionPane.ERROR_MESSAGE);
            } catch (Exception e) {
                JOptionPane.showMessageDialog(this, "Error booking scooter: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    private void refreshDashboard() {
        updateContent("Dashboard");
    }

    private class ScooterCard extends JPanel {
        public ScooterCard(Scooter scooter) {
            setLayout(new BorderLayout(10, 10));
            setBorder(BorderFactory.createLineBorder(Color.GRAY));
            setBackground(Color.WHITE);

            // Scooter image
            JLabel imageLabel = new JLabel();
            imageLabel.setPreferredSize(new Dimension(150, 150));
            imageLabel.setHorizontalAlignment(JLabel.CENTER);
            if (scooter.getImage() != null && scooter.getImage().getUrl() != null) {
                String imagePath = scooter.getImage().getUrl().replace("\"", "");
                String fullImagePath = "http://localhost:8080" + imagePath;
                try {
                    URL url = new URL(fullImagePath);
                    BufferedImage img = ImageIO.read(url);
                    if (img != null) {
                        Image scaledImage = img.getScaledInstance(150, 150, Image.SCALE_SMOOTH);
                        imageLabel.setIcon(new ImageIcon(scaledImage));
                    }
                } catch (IOException e) {
                    e.printStackTrace();
                    imageLabel.setText("Image not available");
                }
            } else {
                imageLabel.setText("No image");
            }
            add(imageLabel, BorderLayout.CENTER);

            // Scooter details
            JPanel detailsPanel = new JPanel(new GridLayout(0, 1, 5, 5));
            detailsPanel.setBackground(Color.WHITE);
            detailsPanel.add(new JLabel("Model: " + scooter.getModel()));
            detailsPanel.add(new JLabel("Year: " + scooter.getYear()));
            detailsPanel.add(new JLabel("Rental Per Day: R" + scooter.getRentalPerDay()));
            detailsPanel.add(new JLabel("Status: " + scooter.getStatus()));
            add(detailsPanel, BorderLayout.SOUTH);

            // Book button
            if (scooter.getStatus() == ScooterStatus.AVAILABLE) {
                JButton bookButton = new JButton("Book");
                bookButton.setBackground(BOOK_BUTTON_COLOR);
                bookButton.setForeground(Color.WHITE);
                bookButton.setFocusPainted(false);
                bookButton.addActionListener(e -> bookScooter(scooter));
                JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
                buttonPanel.setBackground(Color.WHITE);
                buttonPanel.add(bookButton);
                add(buttonPanel, BorderLayout.NORTH);
            }
        }
    }

    private JPanel createSearchPanel() {
        JPanel searchPanel = new JPanel(new BorderLayout(20, 20));
        searchPanel.setBackground(BACKGROUND_COLOR);
        searchPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        // Create search bar
        JTextField searchField = new JTextField();
        searchField.setFont(new Font("Arial", Font.PLAIN, 16));
        searchField.setPreferredSize(new Dimension(100, 30));
        JButton searchButton = createActionButton("Search", e -> performSearch(searchField.getText()));
        JPanel searchBarPanel = new JPanel(new BorderLayout());
        searchBarPanel.add(searchField, BorderLayout.CENTER);
        searchBarPanel.add(searchButton, BorderLayout.EAST);

        searchPanel.add(searchBarPanel, BorderLayout.NORTH);

        // Placeholder for search results
        JPanel resultPanel = new JPanel(new GridLayout(0, 3, 20, 20));
        resultPanel.setBackground(BACKGROUND_COLOR);
        searchPanel.add(resultPanel, BorderLayout.CENTER);

        // Store result panel for later use
        searchPanel.putClientProperty("resultPanel", resultPanel);

        return searchPanel;
    }

    private void performSearch(String query) {
        JPanel searchPanel = (JPanel) contentPanel.getComponent(0);
        JPanel resultPanel = (JPanel) searchPanel.getClientProperty("resultPanel");
        resultPanel.removeAll();

        List<Scooter> results = scooterService.search(query); // Assume this method exists in ScooterService

        if (results.isEmpty()) {
            JLabel noResultLabel = new JLabel("No results found");
            noResultLabel.setFont(new Font("Arial", Font.PLAIN, 18));
            noResultLabel.setForeground(TEXT_COLOR);
            resultPanel.add(noResultLabel);
        } else {
            for (Scooter scooter : results) {
                CustomerDashboard.ScooterCard card = new CustomerDashboard.ScooterCard(scooter);
                resultPanel.add(card);
            }
        }

        resultPanel.revalidate();
        resultPanel.repaint();
    }

    private JButton createActionButton(String text, ActionListener listener) {
        JButton button = new JButton(text);
        button.setFont(new Font("Arial", Font.BOLD, 12));
        button.setForeground(Color.WHITE);
        button.setBackground(ACCENT_COLOR);
        button.setBorderPainted(false);
        button.setFocusPainted(false);
        button.setCursor(new Cursor(Cursor.HAND_CURSOR));
        button.addActionListener(listener);
        return button;
    }
}