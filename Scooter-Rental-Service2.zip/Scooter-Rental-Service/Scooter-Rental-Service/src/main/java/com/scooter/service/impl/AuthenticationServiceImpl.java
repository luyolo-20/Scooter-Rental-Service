package com.scooter.service.impl;

import com.scooter.domain.Customer;
import com.scooter.domain.User;
import com.scooter.service.AuthenticationService;
import com.scooter.service.CustomerService;
import com.scooter.service.UserService;
import org.springframework.stereotype.Service;

@Service
public class AuthenticationServiceImpl implements AuthenticationService {
    private final CustomerService customerService;
    private final UserService userService;

    public AuthenticationServiceImpl(CustomerService customerService, UserService userService) {
        this.customerService = customerService;
        this.userService = userService;
    }

    @Override
    public Object authenticate(String email, String password, String role) {
        if ("CUSTOMER".equalsIgnoreCase(role)) {
            Customer customer = customerService.findByEmail(email);
            if (customer != null && customer.getPassword().equals(password)) {
                Customer responseCustomer = new Customer();
                responseCustomer.setId(customer.getId());
                responseCustomer.setName(customer.getName());
                responseCustomer.setEmail(customer.getEmail());
                responseCustomer.setPassword(customer.getPassword());
                responseCustomer.setPhone(customer.getPhone());

                return responseCustomer;
            }
        } else {
            User user = userService.findByEmail(email);
            if (user != null && user.getPassword().equals(password) &&
                    user.getUserRole().name().equalsIgnoreCase(role)) {
                return user;
            }
        }
        return null;
    }
}
