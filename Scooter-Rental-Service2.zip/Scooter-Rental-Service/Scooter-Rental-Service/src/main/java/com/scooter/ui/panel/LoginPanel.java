package com.scooter.ui.panel;

import com.scooter.ui.service.UIAuthenticationService;

import javax.swing.*;
import java.awt.*;
import java.util.function.BiConsumer;

public class LoginPanel extends JPanel {
    private JTextField emailField;
    private JPasswordField passwordField;
    private JComboBox<String> roleComboBox;
    private JButton loginButton;
    private UIAuthenticationService authService;
    private BiConsumer<String, Object> onLoginSuccess;

    public LoginPanel(UIAuthenticationService authService, BiConsumer<String, Object> onLoginSuccess) {
        this.authService = authService;
        this.onLoginSuccess = onLoginSuccess;
        setLayout(new GridBagLayout());
        setBackground(new Color(60, 63, 65));  // Dark background
        initComponents();
    }

    private void initComponents() {
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        JLabel titleLabel = new JLabel("Scooter Rental System Login");
        titleLabel.setFont(new Font("Arial", Font.BOLD, 22));
        titleLabel.setForeground(new Color(255, 255, 255));
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 2;
        gbc.anchor = GridBagConstraints.CENTER;
        add(titleLabel, gbc);

        gbc.gridwidth = 1;
        gbc.anchor = GridBagConstraints.WEST;

        gbc.gridx = 0;
        gbc.gridy = 1;
        add(createStyledLabel("Email:"), gbc);

        gbc.gridx = 1;
        emailField = createStyledTextField(20);
        add(emailField, gbc);

        gbc.gridx = 0;
        gbc.gridy = 2;
        add(createStyledLabel("Password:"), gbc);

        gbc.gridx = 1;
        passwordField = createStyledPasswordField(20);
        add(passwordField, gbc);

        gbc.gridx = 0;
        gbc.gridy = 3;
        add(createStyledLabel("Role:"), gbc);

        gbc.gridx = 1;
        String[] roles = {"Customer", "Employee", "Admin"};
        roleComboBox = createStyledComboBox(roles);
        add(roleComboBox, gbc);

        gbc.gridx = 1;
        gbc.gridy = 4;
        gbc.gridwidth = 2;
        loginButton = createStyledButton("Login");
        add(loginButton, gbc);

        loginButton.addActionListener(e -> login());
    }

    private void login() {
        String email = emailField.getText();
        String password = new String(passwordField.getPassword());
        String role = (String) roleComboBox.getSelectedItem();

        Object loggedInUser = authService.login(email, password, role);
        if (loggedInUser != null) {
            onLoginSuccess.accept(role, loggedInUser);
        } else {
            JOptionPane.showMessageDialog(this, "Login failed. Please try again.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    public void reset() {
        emailField.setText("");
        passwordField.setText("");
        roleComboBox.setSelectedIndex(0);
    }

    private JLabel createStyledLabel(String text) {
        JLabel label = new JLabel(text);
        label.setFont(new Font("Arial", Font.BOLD, 16));
        label.setForeground(new Color(255, 255, 255));
        return label;
    }

    private JTextField createStyledTextField(int columns) {
        JTextField textField = new JTextField(columns);
        textField.setFont(new Font("Arial", Font.PLAIN, 16));
        textField.setForeground(new Color(60, 63, 65));
        textField.setBackground(new Color(245, 245, 245));
        textField.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));
        return textField;
    }

    private JPasswordField createStyledPasswordField(int columns) {
        JPasswordField passwordField = new JPasswordField(columns);
        passwordField.setFont(new Font("Arial", Font.PLAIN, 16));
        passwordField.setForeground(new Color(60, 63, 65));
        passwordField.setBackground(new Color(245, 245, 245));
        passwordField.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));
        return passwordField;
    }

    private JComboBox<String> createStyledComboBox(String[] items) {
        JComboBox<String> comboBox = new JComboBox<>(items);
        comboBox.setFont(new Font("Arial", Font.PLAIN, 16));
        comboBox.setForeground(new Color(60, 63, 65));
        comboBox.setBackground(new Color(245, 245, 245));
        comboBox.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));
        return comboBox;
    }

    private JButton createStyledButton(String text) {
        JButton button = new JButton(text);
        button.setFont(new Font("Arial", Font.BOLD, 18));
        button.setForeground(Color.WHITE);
        button.setBackground(new Color(0, 123, 255));
        button.setBorderPainted(false);
        button.setFocusPainted(false);
        button.setCursor(new Cursor(Cursor.HAND_CURSOR));
        button.setPreferredSize(new Dimension(150, 40));
        return button;
    }
}
