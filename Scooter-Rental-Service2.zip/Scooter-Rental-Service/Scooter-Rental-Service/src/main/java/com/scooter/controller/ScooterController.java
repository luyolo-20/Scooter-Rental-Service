package com.scooter.controller;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.scooter.domain.Customer;
import com.scooter.domain.Scooter;
import com.scooter.factory.CustomerRQ;
import com.scooter.factory.ScooterRQ;
import com.scooter.service.ScooterService;
import lombok.AllArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;

@RestController
@RequestMapping("/scooters")
@AllArgsConstructor
public class ScooterController {
    private ScooterService scooterService;

    @GetMapping("")
    public List<Scooter> list() {
        return scooterService.getAll();
    }

    @GetMapping("/{id}")
    public Scooter getById(@PathVariable Long id) {
        return scooterService.getById(id);
    }

    @PostMapping(value = "", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    public Scooter create(@RequestPart("form") String formJson, @RequestPart("file") MultipartFile file) throws JsonProcessingException, JsonProcessingException {
        ObjectMapper mapper = new ObjectMapper();
        ScooterRQ form = mapper.readValue(formJson, ScooterRQ.class);
        return scooterService.create(form, file);
    }

    @PutMapping("/{id}")
    public Scooter update(@PathVariable Long id, @RequestBody ScooterRQ form, @RequestPart(name = "file") MultipartFile file) {
        return scooterService.update(id, form, file);
    }

    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void deleteById(@PathVariable Long id) {
        scooterService.delete(id);
    }

    @GetMapping("/search")
    public List<Scooter> search(@RequestParam(required = false) String q) {
        return scooterService.search(q);
    }
}
