package com.scooter.factory;

import com.scooter.enums.Model;
import com.scooter.enums.ScooterStatus;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class ScooterRQ {
    private Model model;

    private int year;

    private int rentalPerDay;

    private ScooterStatus scooterStatus;
}
