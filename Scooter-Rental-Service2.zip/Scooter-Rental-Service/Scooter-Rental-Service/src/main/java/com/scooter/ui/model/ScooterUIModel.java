package com.scooter.ui.model;

public class ScooterUIModel {
}
