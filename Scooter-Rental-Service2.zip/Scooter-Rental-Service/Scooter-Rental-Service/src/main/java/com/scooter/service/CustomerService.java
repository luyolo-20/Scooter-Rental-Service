package com.scooter.service;

import com.scooter.domain.Customer;
import com.scooter.factory.CustomerRQ;

public interface CustomerService extends BaseCrudService<Customer, Long>{
    Customer create(CustomerRQ form);

    Customer update(Long id, CustomerRQ form);

    Customer findByEmail(String email);
}
