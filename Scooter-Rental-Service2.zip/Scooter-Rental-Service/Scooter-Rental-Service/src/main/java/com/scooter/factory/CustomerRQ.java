package com.scooter.factory;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class CustomerRQ {
    private String name;

    private String email;

    private String password;

    private String phone;

    private String nic;
}
