package com.scooter.service;

import com.scooter.domain.RentalDetail;
import com.scooter.factory.RentalRQ;

import java.util.List;

public interface RentalService extends BaseCrudService<RentalDetail, Long>{
    RentalDetail create(RentalRQ form);

    RentalDetail update(Long id, RentalRQ form);

    RentalDetail acceptRental(Long id);

    RentalDetail rejectRental(Long id);

    RentalDetail completeRental(Long id);

    List<RentalDetail> getRentalsByCustomerId(Long id);
}
