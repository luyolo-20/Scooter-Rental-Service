package com.scooter.ui.service;

public class UIScooterService {
}
