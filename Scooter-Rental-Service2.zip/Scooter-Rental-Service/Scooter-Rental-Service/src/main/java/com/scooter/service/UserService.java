package com.scooter.service;

import com.scooter.domain.User;
import com.scooter.factory.UserRQ;

public interface UserService extends BaseCrudService<User, Long>{
    User create(UserRQ form);

    User update(Long id, UserRQ form);

    User findByEmail(String email);
}
