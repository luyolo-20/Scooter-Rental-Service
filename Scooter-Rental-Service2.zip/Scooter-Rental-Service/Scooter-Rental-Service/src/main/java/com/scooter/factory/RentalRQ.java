package com.scooter.factory;

import com.scooter.enums.RentalStatus;
import lombok.Getter;
import lombok.Setter;

import java.time.LocalDate;

@Getter
@Setter
public class RentalRQ {
    private Long customerId;

    private Long scooterId;

    private LocalDate startDate;

    private int noOfDates;

}
