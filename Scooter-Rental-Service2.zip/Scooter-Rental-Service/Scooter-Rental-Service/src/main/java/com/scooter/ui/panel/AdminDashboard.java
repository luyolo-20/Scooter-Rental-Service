package com.scooter.ui.panel;

import com.scooter.domain.Scooter;
import com.scooter.domain.User;
import com.scooter.service.*;
import com.scooter.ui.dialog.UpdateScooterDialog;
import lombok.Setter;

import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.net.URL;
import java.util.List;

public class AdminDashboard extends JPanel {
    private CardLayout cardLayout;
    private JPanel contentPanel;
    private String[] tabs = {"Dashboard", "Employees", "Customers", "Scooters", "Rentals", "Search", "Profile", "Logout"};
    private UserService userService;
    private CustomerService customerService;
    private ScooterService scooterService;
    private FileStoreService fileStoreService;
    private RentalService rentalService;
    private User loggedInAdmin;
    @Setter
    private LogoutListener logoutListener;

    private static final Color BACKGROUND_COLOR = new Color(240, 240, 245);
    private static final Color HEADER_COLOR = new Color(60, 60, 60);
    private static final Color ACCENT_COLOR = new Color(0, 123, 255);
    private static final Color CARD_COLOR = new Color(255, 255, 255);
    private static final Color TEXT_COLOR = new Color(33, 37, 41);

    public AdminDashboard(UserService userService, CustomerService customerService, ScooterService scooterService, FileStoreService fileStoreService, RentalService rentalService) {
        this.userService = userService;
        this.customerService = customerService;
        this.scooterService = scooterService;
        this.fileStoreService = fileStoreService;
        this.rentalService = rentalService;
        setLayout(new BorderLayout());

        // Create header panel
        JPanel headerPanel = createHeaderPanel();
        add(headerPanel, BorderLayout.NORTH);
        setBackground(BACKGROUND_COLOR);

        // Create content panel
        contentPanel = new JPanel();
        cardLayout = new CardLayout();
        contentPanel.setLayout(cardLayout);
        add(contentPanel, BorderLayout.CENTER);

        // Initialize with Dashboard content
        showDashboard();
    }

    public void setLoggedInAdmin(User admin) {
        this.loggedInAdmin = admin;
        SwingUtilities.invokeLater(this::updateDashboardContent);
    }

    private void updateDashboardContent() {
        if (loggedInAdmin != null) {
            JPanel dashboardPanel = createDashboardPanel();
            contentPanel.removeAll();
            contentPanel.add(dashboardPanel, "Dashboard");
            cardLayout.show(contentPanel, "Dashboard");
            contentPanel.revalidate();
            contentPanel.repaint();
        }
    }

    private JPanel createHeaderPanel() {
        JPanel headerPanel = new JPanel(new BorderLayout());
        headerPanel.setBackground(HEADER_COLOR);
        headerPanel.setBorder(BorderFactory.createEmptyBorder(10, 20, 10, 20));

        JLabel systemLabel = new JLabel("Scooter Rental System");
        systemLabel.setFont(new Font("Arial", Font.BOLD, 24));
        systemLabel.setForeground(Color.WHITE);
        headerPanel.add(systemLabel, BorderLayout.WEST);

        JLabel dashboardLabel = new JLabel("Admin Dashboard");
        dashboardLabel.setFont(new Font("Arial", Font.PLAIN, 18));
        dashboardLabel.setForeground(Color.WHITE);
        headerPanel.add(dashboardLabel, BorderLayout.EAST);

        JPanel navPanel = createNavPanel();
        headerPanel.add(navPanel, BorderLayout.SOUTH);

        return headerPanel;
    }

    private JPanel createNavPanel() {
        JPanel navPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 5));
        navPanel.setBackground(HEADER_COLOR);

        for (String tabName : tabs) {
            JButton tabButton = createStyledButton(tabName);
            navPanel.add(tabButton);
        }

        return navPanel;
    }

    private JButton createStyledButton(String text) {
        JButton button = new JButton(text) {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                if (getModel().isPressed()) {
                    g2.setColor(ACCENT_COLOR.darker());
                } else if (getModel().isRollover()) {
                    g2.setColor(ACCENT_COLOR.brighter());
                } else {
                    g2.setColor(ACCENT_COLOR);
                }
                g2.fillRoundRect(0, 0, getWidth(), getHeight(), 10, 10);
                g2.setColor(Color.WHITE);
                g2.setFont(getFont().deriveFont(Font.BOLD));
                FontMetrics fm = g2.getFontMetrics();
                int x = (getWidth() - fm.stringWidth(getText())) / 2;
                int y = (getHeight() + fm.getAscent() - fm.getDescent()) / 2;
                g2.drawString(getText(), x, y);
                g2.dispose();
            }
        };
        button.setForeground(Color.WHITE);
        button.setFont(new Font("Arial", Font.BOLD, 14));
        button.setPreferredSize(new Dimension(120, 40));
        button.setBorderPainted(false);
        button.setFocusPainted(false);
        button.setContentAreaFilled(false);
        button.setCursor(new Cursor(Cursor.HAND_CURSOR));
        button.addActionListener(e -> updateContent(text));
        return button;
    }

    private void updateContent(String selectedTab) {
        contentPanel.removeAll();
        JPanel newPanel;

        switch (selectedTab) {
            case "Employees":
                newPanel = new EmployeesPanel(userService);
                break;
            case "Customers":
                newPanel = new CustomersPanel(customerService);
                break;
            case "Scooters":
                newPanel = new ScootersPanel(scooterService, fileStoreService);
                break;
            case "Rentals":
                newPanel = new RentalsPanel(rentalService);
                break;
            case "Profile":
                newPanel = new ProfilePanel(loggedInAdmin, userService);
                break;
            case "Dashboard":
                newPanel = createDashboardPanel();
                break;
            case "Search":
                newPanel = createSearchPanel();  // New search panel
                break;
            case "Logout":
                handleLogout();
                return;
            default:
                newPanel = new JPanel();
                newPanel.add(new JLabel(selectedTab + " Content"));
        }

        contentPanel.add(newPanel, selectedTab);
        cardLayout.show(contentPanel, selectedTab);
        contentPanel.revalidate();
        contentPanel.repaint();
    }

    private JPanel createDashboardPanel() {
        JPanel dashboardPanel = new JPanel(new BorderLayout(20, 20));
        dashboardPanel.setBackground(BACKGROUND_COLOR);
        dashboardPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        JLabel welcomeLabel = new JLabel("Welcome, " + (loggedInAdmin != null ? loggedInAdmin.getName() : "Admin"));
        welcomeLabel.setFont(new Font("Arial", Font.BOLD, 24));
        welcomeLabel.setForeground(TEXT_COLOR);
        dashboardPanel.add(welcomeLabel, BorderLayout.NORTH);

        JPanel scooterCardsPanel = new JPanel(new GridLayout(0, 3, 20, 20));
        scooterCardsPanel.setBackground(BACKGROUND_COLOR);
        List<Scooter> scooters = scooterService.getAll();
        for (Scooter scooter : scooters) {
            ScooterCard card = new ScooterCard(scooter);
            scooterCardsPanel.add(card);
        }

        JScrollPane scrollPane = new JScrollPane(scooterCardsPanel);
        scrollPane.setBackground(BACKGROUND_COLOR);
        scrollPane.setBorder(BorderFactory.createEmptyBorder());
        dashboardPanel.add(scrollPane, BorderLayout.CENTER);

        return dashboardPanel;
    }

    private void showDashboard() {
        updateContent("Dashboard");
    }

    private void handleLogout() {
        int confirm = JOptionPane.showConfirmDialog(this,
                "Are you sure you want to logout?", "Confirm Logout",
                JOptionPane.YES_NO_OPTION);
        if (confirm == JOptionPane.YES_OPTION) {
            // TODO: Implement logout logic
            System.out.println("Logout initiated");
            if (logoutListener != null) {
                logoutListener.onLogout();
            }
        }
    }

    public interface LogoutListener {
        void onLogout();
    }

    private void updateScooter(Scooter scooter) {
        // Open update dialog
        UpdateScooterDialog dialog = new UpdateScooterDialog(scooter, scooterService);
        dialog.setVisible(true);
        if (dialog.isUpdateSuccessful()) {
            refreshDashboard();
        }
    }

    private void deleteScooter(Scooter scooter) {
        int confirm = JOptionPane.showConfirmDialog(this,
                "Are you sure you want to delete this scooter?",
                "Confirm Delete", JOptionPane.YES_NO_OPTION);
        if (confirm == JOptionPane.YES_OPTION) {
            scooterService.delete(scooter.getId());
            refreshDashboard();
        }
    }

    private void refreshDashboard() {
        contentPanel.removeAll();
        JPanel newDashboardPanel = createDashboardPanel();
        contentPanel.add(newDashboardPanel, "Dashboard");
        cardLayout.show(contentPanel, "Dashboard");
        contentPanel.revalidate();
        contentPanel.repaint();
    }

    private class ScooterCard extends JPanel {
        public ScooterCard(Scooter scooter) {
            setLayout(new BorderLayout(10, 10));
            setBorder(BorderFactory.createCompoundBorder(
                    BorderFactory.createLineBorder(ACCENT_COLOR, 2),
                    BorderFactory.createEmptyBorder(10, 10, 10, 10)
            ));
            setBackground(CARD_COLOR);

            // Scooter image
            JLabel imageLabel = createImageLabel(scooter);
            add(imageLabel, BorderLayout.CENTER);

            // Scooter details
            JPanel detailsPanel = createDetailsPanel(scooter);
            add(detailsPanel, BorderLayout.SOUTH);

            // Action buttons
            JPanel buttonPanel = createButtonPanel(scooter);
            add(buttonPanel, BorderLayout.NORTH);
        }

        private JLabel createImageLabel(Scooter scooter) {
            JLabel imageLabel = new JLabel();
            imageLabel.setPreferredSize(new Dimension(150, 150));
            imageLabel.setHorizontalAlignment(JLabel.CENTER);
            imageLabel.setVerticalAlignment(JLabel.CENTER);

            if (scooter.getImage() != null && scooter.getImage().getUrl() != null) {
                String imagePath = scooter.getImage().getUrl().replace("\"", "");
                String fullImagePath = "http://localhost:8080" + imagePath;
                try {
                    URL url = new URL(fullImagePath);
                    BufferedImage img = ImageIO.read(url);
                    if (img != null) {
                        Image scaledImage = img.getScaledInstance(150, 150, Image.SCALE_SMOOTH);
                        imageLabel.setIcon(new ImageIcon(scaledImage));
                    }
                } catch (IOException e) {
                    e.printStackTrace();
                    imageLabel.setText("Image not available");
                }
            } else {
                imageLabel.setText("No image");
            }
            return imageLabel;
        }

        private JPanel createDetailsPanel(Scooter scooter) {
            JPanel detailsPanel = new JPanel(new GridLayout(0, 1, 5, 5));
            detailsPanel.setBackground(CARD_COLOR);
            detailsPanel.add(createStyledLabel("Model: " + scooter.getModel()));
            detailsPanel.add(createStyledLabel("Year: " + scooter.getYear()));
            detailsPanel.add(createStyledLabel("Rental Per Day: R" + scooter.getRentalPerDay()));
            detailsPanel.add(createStyledLabel("Status: " + scooter.getStatus()));
            return detailsPanel;
        }

        private JLabel createStyledLabel(String text) {
            JLabel label = new JLabel(text);
            label.setFont(new Font("Arial", Font.PLAIN, 14));
            label.setForeground(TEXT_COLOR);
            return label;
        }

        private JPanel createButtonPanel(Scooter scooter) {
            JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 5, 0));
            buttonPanel.setBackground(CARD_COLOR);
            JButton updateButton = createActionButton("Update", e -> updateScooter(scooter), ACCENT_COLOR);
            JButton deleteButton = createActionButton("Delete", e -> deleteScooter(scooter), Color.RED);
            buttonPanel.add(updateButton);
            buttonPanel.add(deleteButton);
            return buttonPanel;
        }

        private JButton createActionButton(String text, ActionListener listener, Color buttonColor) {
            JButton button = new JButton(text);
            button.setFont(new Font("Arial", Font.BOLD, 12));
            button.setForeground(Color.WHITE);
            button.setBackground(buttonColor);
            button.setBorderPainted(false);
            button.setFocusPainted(false);
            button.setCursor(new Cursor(Cursor.HAND_CURSOR));
            button.addActionListener(listener);
            return button;
        }

        }

    private JPanel createSearchPanel() {
        JPanel searchPanel = new JPanel(new BorderLayout(20, 20));
        searchPanel.setBackground(BACKGROUND_COLOR);
        searchPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        // Create search bar
        JTextField searchField = new JTextField();
        searchField.setFont(new Font("Arial", Font.PLAIN, 16));
        searchField.setPreferredSize(new Dimension(200, 30));
        JButton searchButton = createActionButton("Search", e -> performSearch(searchField.getText()));
        JPanel searchBarPanel = new JPanel(new BorderLayout());
        searchBarPanel.add(searchField, BorderLayout.CENTER);
        searchBarPanel.add(searchButton, BorderLayout.EAST);

        searchPanel.add(searchBarPanel, BorderLayout.NORTH);

        // Placeholder for search results
        JPanel resultPanel = new JPanel(new GridLayout(0, 3, 20, 20));
        resultPanel.setBackground(BACKGROUND_COLOR);
        searchPanel.add(resultPanel, BorderLayout.CENTER);

        // Store result panel for later use
        searchPanel.putClientProperty("resultPanel", resultPanel);

        return searchPanel;
    }

    private void performSearch(String query) {
        JPanel searchPanel = (JPanel) contentPanel.getComponent(0);
        JPanel resultPanel = (JPanel) searchPanel.getClientProperty("resultPanel");
        resultPanel.removeAll();

        List<Scooter> results = scooterService.search(query); // Assume this method exists in ScooterService

        if (results.isEmpty()) {
            JLabel noResultLabel = new JLabel("No results found");
            noResultLabel.setFont(new Font("Arial", Font.PLAIN, 18));
            noResultLabel.setForeground(TEXT_COLOR);
            resultPanel.add(noResultLabel);
        } else {
            for (Scooter scooter : results) {
                ScooterCard card = new ScooterCard(scooter);
                resultPanel.add(card);
            }
        }

        resultPanel.revalidate();
        resultPanel.repaint();
    }

    private JButton createActionButton(String text, ActionListener listener) {
        JButton button = new JButton(text);
        button.setFont(new Font("Arial", Font.BOLD, 12));
        button.setForeground(Color.WHITE);
        button.setBackground(ACCENT_COLOR);
        button.setBorderPainted(false);
        button.setFocusPainted(false);
        button.setCursor(new Cursor(Cursor.HAND_CURSOR));
        button.addActionListener(listener);
        return button;
    }
}

