package com.scooter.service;


import com.scooter.domain.Attachment;
import com.scooter.exception.FileStoreException;
import org.springframework.core.io.Resource;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;

public interface FileStoreService {
    Attachment storeFile(String relativePath, MultipartFile file) throws FileStoreException;

    String getPublicUrl(String relativePath);

    void deleteFile(String currentImage) throws FileStoreException;

    byte[] getFileAsByteArray(String path) throws IOException;

    Resource loadAsResource(String filename);
}
